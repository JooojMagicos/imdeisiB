package pt.ulusofona.aed.deisimdb;

import java.util.ArrayList;

public class Commands {


}
