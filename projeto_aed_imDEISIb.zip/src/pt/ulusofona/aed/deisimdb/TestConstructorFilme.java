package pt.ulusofona.aed.deisimdb;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class TestConstructorFilme {

    @Test
    void testConstructorDateFormat() {
        ConstructorFilme filme = new ConstructorFilme(1, "Filme A", "01-12-2020");
        assertEquals("2020-12-01", filme.toString().split(" \\| ")[2], "Formato da data deve ser yyyy-MM-dd");
    }

    @Test
    void testGetIdFilme() {
        ConstructorFilme filme = new ConstructorFilme(2, "Filme B", "15-08-2019");
        assertEquals(2, filme.getIdFilme(), "O ID do filme deve ser 2");
    }

    @Test
    void testToStringFormatIdAbove1000() {
        ConstructorFilme filme = new ConstructorFilme(1500, "Filme C", "10-05-2018");
        String expected = "1500 | Filme C | 2018-05-10";
        assertEquals(expected, filme.toString(), "Formato de saída do toString está incorreto para ID > 1000");
    }

    @Test
    void testToStringFormatIdBelow1000() {
        ConstructorFilme filme = new ConstructorFilme(500, "Filme D", "22-03-2017");
        String expected = "500 | Filme D | 2017-03-22 | 2";
        assertEquals(expected, filme.toString(), "Formato de saída do toString está incorreto para ID <= 1000");
    }

    @Test
    void testInvalidDateFormat() {
        ConstructorFilme filme = new ConstructorFilme(3, "Filme E", "2020-12-01");
        assertNotEquals("2020-12-01", filme.toString().split(" \\| ")[2], "Data no formato errado não deve ser aceita");
    }
}
