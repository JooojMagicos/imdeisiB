package pt.ulusofona.aed.deisimdb;

public class ConstructorFilme {

    private int id;
    private String nome;
    private String ano;



    public ConstructorFilme(int id, String nome, String ano)
    {
        this.id = id;
        this.nome = nome;

        String[] anoInvertido = ano.split("-");
        this.ano = anoInvertido[2].trim()+"-"+anoInvertido[1].trim()+"-"+anoInvertido[0].trim();


    }
    public int getIdFilme()
        {
            return id;
        }

    @Override
    public String toString() {
        if (id>1000){
            return  id + " | " + nome + " | " + ano;
        }
        else
        {
            return  id + " | " + nome + " | " + ano + " | 2";
        }

    }
}
