package pt.ulusofona.aed.deisimdb;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TestConstructorAtor {

    @Test
    void testConstructorValidMale() {
        ConstructorAtor ator = new ConstructorAtor(1, "João", "M", 100);
        assertEquals("Masculino", ator.toString().split(" \\| ")[2], "Gênero deve ser Masculino");
    }

    @Test
    void testConstructorValidFemale() {
        ConstructorAtor ator = new ConstructorAtor(2, "Maria", "F", 101);
        assertEquals("Feminino", ator.toString().split(" \\| ")[2], "Gênero deve ser Feminino");
    }

    @Test
    void testConstructorInvalidGender() {
        ConstructorAtor ator = new ConstructorAtor(3, "Alex", "X", 102);
        assertNull(ator.toString().split(" \\| ")[2], "Gênero inválido deve resultar em null");
    }

    @Test
    void testGetIdActor() {
        ConstructorAtor ator = new ConstructorAtor(4, "Carlos", "M", 103);
        assertEquals(4, ator.getIdActor(), "O ID do ator deve ser 4");
    }

    @Test
    void testToStringFormat() {
        ConstructorAtor ator = new ConstructorAtor(5, "Ana", "F", 104);
        String expected = "5 | Ana | Feminino | 104";
        assertEquals(expected, ator.toString(), "Formato de saída do toString está incorreto");
    }
}

